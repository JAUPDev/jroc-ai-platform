/**
 * J-Roc OS 5.0 — Auto-Fix Worker: Slack / Webhook Notifier
 */
'use strict';

const axios  = require('axios');
const cfg    = require('./config');
const logger = require('./logger');

async function sendWebhook(payload) {
  if (!cfg.notify.webhookUrl) return;
  try {
    await axios.post(cfg.notify.webhookUrl, payload, { timeout: 8000 });
  } catch (err) {
    logger.warn('notifier', `Webhook delivery failed: ${err.message}`);
  }
}

async function notifyFix({ runId, workflow, patterns, results }) {
  if (!cfg.notify.onFix) return;
  await sendWebhook({
    text: `✅ *J-Roc OS Auto-Fix* applied ${patterns.length} patch(es) to workflow run #${runId} (${workflow})`,
    attachments: results.map((r) => ({
      color:  r.success ? 'good' : 'danger',
      text:   `*${r.pattern}*: ${r.result}`,
    })),
  });
}

async function notifyFailure({ runId, workflow, reason }) {
  if (!cfg.notify.onFailure) return;
  await sendWebhook({
    text: `🚨 *J-Roc OS Auto-Fix FAILED* on run #${runId} (${workflow})\n> ${reason}`,
  });
}

async function notifyNightPatrol({ scanned, issues }) {
  await sendWebhook({
    text: `🌙 *Night Patrol complete* — scanned ${scanned} runs, found ${issues} issue(s)`,
  });
}

module.exports = { notifyFix, notifyFailure, notifyNightPatrol };
