/**
 * J-Roc OS 5.0 — Night Patrol Worker
 * Runs deep scheduled audits across all workflows.
 */
'use strict';

const gh       = require('../github-client');
const notifier = require('../notifier');
const logger   = require('../logger');

const NAME = 'NightPatrol';

const WATCHED_WORKFLOWS = ['expo-apk.yml', 'auto-fix-worker.yml'];

async function run() {
  logger.info(NAME, '🌙 Night Patrol deep scan initiated');

  let totalScanned = 0;
  let totalFailures = 0;
  let totalWarnings = 0;
  const report = [];

  for (const workflow of WATCHED_WORKFLOWS) {
    const runs = await gh.getLatestRuns(workflow, 30).catch(() => []);
    const failures = runs.filter((r) => r.conclusion === 'failure');
    const warnings = runs.filter((r) => r.conclusion === 'timed_out' || r.conclusion === 'cancelled');

    totalScanned  += runs.length;
    totalFailures += failures.length;
    totalWarnings += warnings.length;

    report.push({
      workflow,
      runs:     runs.length,
      failures: failures.length,
      warnings: warnings.length,
      successRate: runs.length > 0
        ? `${Math.round(((runs.length - failures.length) / runs.length) * 100)}%`
        : 'N/A',
    });

    logger.info(NAME, `${workflow}: ${runs.length} runs, ${failures.length} failures, ${warnings.length} warnings`);
  }

  // Log summary table
  logger.info(NAME, '─── Night Patrol Report ───────────────────');
  for (const row of report) {
    logger.info(NAME, `${row.workflow}: ${row.successRate} success (${row.runs} runs, ${row.failures} fail, ${row.warnings} warn)`);
  }
  logger.info(NAME, `Total: ${totalScanned} runs, ${totalFailures} failures, ${totalWarnings} warnings`);
  logger.info(NAME, '───────────────────────────────────────────');

  await notifier.notifyNightPatrol({ scanned: totalScanned, issues: totalFailures + totalWarnings });

  return { scanned: totalScanned, failures: totalFailures, warnings: totalWarnings, report };
}

module.exports = { NAME, run };
