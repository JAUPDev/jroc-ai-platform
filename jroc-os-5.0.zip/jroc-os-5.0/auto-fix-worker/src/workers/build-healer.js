/**
 * J-Roc OS 5.0 — Build Healer Worker
 * Specializes in Expo / EAS build failure recovery.
 */
'use strict';

const gh     = require('../github-client');
const logger = require('../logger');

const NAME = 'BuildHealer';

async function run() {
  logger.info(NAME, 'Build Healer cycle starting');

  const runs = await gh.getLatestRuns('expo-apk.yml', 5);
  const failed = runs.filter((r) => r.conclusion === 'failure');

  if (failed.length === 0) {
    logger.info(NAME, 'No failed EAS builds — all good');
    return { healed: 0 };
  }

  let healed = 0;
  for (const run of failed) {
    logger.info(NAME, `Attempting re-run for failed run #${run.id}`);
    try {
      await gh.reRunFailedJobs(run.id);
      healed++;
    } catch (err) {
      logger.error(NAME, `Could not re-run #${run.id}: ${err.message}`);
    }
  }

  logger.info(NAME, `Build Healer cycle complete — healed: ${healed}`);
  return { healed };
}

module.exports = { NAME, run };
