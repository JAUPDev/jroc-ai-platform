/**
 * J-Roc OS 5.0 — Dependency Resolver Worker
 * Detects and resolves npm/yarn dependency conflicts automatically.
 */
'use strict';

const gh     = require('../github-client');
const logger = require('../logger');

const NAME = 'DepResolver';

// Known peer-dep fix patches
const DEP_FIXES = {
  'react-native-vector-icons': {
    match: /peer dep.*react-native-vector-icons|vector-icons.*mismatch/i,
    fix: async () => ({
      file: 'app/package.json',
      transform: (content) => {
        const pkg = JSON.parse(content);
        pkg.resolutions = pkg.resolutions || {};
        pkg.resolutions['react-native-vector-icons'] = '^10.1.0';
        return JSON.stringify(pkg, null, 2) + '\n';
      },
      message: 'fix(deps): add resolution for react-native-vector-icons peer dep',
    }),
  },
  'metro-config': {
    match: /metro.*config.*not found|cannot resolve metro/i,
    fix: async () => ({
      file: 'app/package.json',
      transform: (content) => {
        const pkg = JSON.parse(content);
        pkg.dependencies['metro-config'] = pkg.dependencies['metro-config'] || '^0.80.0';
        return JSON.stringify(pkg, null, 2) + '\n';
      },
      message: 'fix(deps): add explicit metro-config dependency',
    }),
  },
};

async function run() {
  logger.info(NAME, 'Dependency Resolver cycle starting');
  const results = { checked: 0, fixed: 0, skipped: 0 };

  const runs = await gh.getLatestRuns('expo-apk.yml', 10);
  const failed = runs.filter((r) => r.conclusion === 'failure');
  results.checked = failed.length;

  for (const run of failed) {
    const logBuffer = await gh.getRunLogs(run.id).catch(() => null);
    if (!logBuffer) { results.skipped++; continue; }
    const logText = logBuffer.toString('utf8');

    for (const [pkg, descriptor] of Object.entries(DEP_FIXES)) {
      if (!descriptor.match.test(logText)) continue;

      logger.info(NAME, `Matched dep issue: ${pkg} in run #${run.id}`);
      try {
        const fix = await descriptor.fix();
        const { content, sha } = await gh.getFileContent(fix.file);
        const patched = fix.transform(content);
        await gh.updateFile(fix.file, patched, fix.message, sha);
        results.fixed++;
        logger.info(NAME, `Fixed ${pkg} in ${fix.file}`);
      } catch (err) {
        logger.error(NAME, `Failed to fix ${pkg}: ${err.message}`);
        results.skipped++;
      }
    }
  }

  logger.info(NAME, `DepResolver complete — checked: ${results.checked}, fixed: ${results.fixed}, skipped: ${results.skipped}`);
  return results;
}

module.exports = { NAME, run };
