/**
 * J-Roc OS 5.0 — Lint Guard Worker
 * Monitors code quality and auto-fixes lint violations where safe.
 */
'use strict';

const { execa }  = require('execa');
const logger     = require('../logger');
const gh         = require('../github-client');

const NAME = 'LintGuard';

// Safe auto-fixable ESLint rules
const SAFE_FIX_RULES = [
  'import/order',
  'semi',
  'quotes',
  'no-trailing-spaces',
  'eol-last',
  'comma-dangle',
];

async function run() {
  logger.info(NAME, 'Lint Guard cycle starting');
  const results = { checked: 0, fixed: 0, escalated: 0 };

  const runs = await gh.getLatestRuns('expo-apk.yml', 10);
  const lintFailed = runs.filter(
    (r) => r.conclusion === 'failure' && /lint/i.test(r.name || '')
  );

  results.checked = lintFailed.length;

  for (const run of lintFailed) {
    const jobs = await gh.getRunJobs(run.id).catch(() => []);
    const lintJob = jobs.find((j) => /lint/i.test(j.name) && j.conclusion === 'failure');
    if (!lintJob) continue;

    logger.info(NAME, `Lint failure in run #${run.id} — attempting auto-fix`);

    // Determine if failure was a safe-fixable rule by checking job steps
    const isSafeFix = lintJob.steps?.some((s) =>
      SAFE_FIX_RULES.some((rule) => s.name?.includes(rule))
    );

    if (isSafeFix) {
      await gh.triggerWorkflow('auto-fix-worker.yml', 'main', { action: 'lint-fix' });
      results.fixed++;
      logger.info(NAME, `Safe lint fix dispatched for run #${run.id}`);
    } else {
      await gh.createIssue(
        `[LintGuard] Non-trivial lint failure in run #${run.id}`,
        `Lint failure detected that is not safe for automatic fixing.\n\nRun: #${run.id}\nJob: ${lintJob.name}`,
        ['lint', 'needs-review']
      );
      results.escalated++;
    }
  }

  logger.info(NAME, `Lint Guard complete — checked: ${results.checked}, fixed: ${results.fixed}, escalated: ${results.escalated}`);
  return results;
}

module.exports = { NAME, run };
