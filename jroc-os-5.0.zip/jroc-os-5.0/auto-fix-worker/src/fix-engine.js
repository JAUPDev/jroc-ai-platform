/**
 * J-Roc OS 5.0 — Auto-Fix Worker: Fix Engine
 * Analyzes failure patterns and applies targeted patches.
 */
'use strict';

const gh     = require('./github-client');
const logger = require('./logger');

// ── Known Fix Patterns ────────────────────────────────────────────────────────
// Each pattern has a regex to match log output and an async fixer function.

const FIX_PATTERNS = [
  {
    name:  'MetroBundlerTimeout',
    regex: /metro.*timeout|bundler.*timed out/i,
    async fix(context) {
      logger.info('fix-engine', 'Applying MetroBundlerTimeout fix — patching metro.config.js');
      const { content, sha } = await gh.getFileContent('app/metro.config.js').catch(() => ({
        content: null, sha: null,
      }));
      const base = content || `const { getDefaultConfig } = require('expo/metro-config');\nmodule.exports = getDefaultConfig(__dirname);\n`;
      const patched = base.includes('resolver')
        ? base
        : base.replace(
            /module\.exports\s*=\s*getDefaultConfig\(__dirname\);/,
            `const config = getDefaultConfig(__dirname);\nconfig.resolver.sourceExts = [...(config.resolver.sourceExts || []), 'cjs'];\nmodule.exports = config;`
          );
      if (sha) {
        await gh.updateFile('app/metro.config.js', patched, 'fix(metro): add cjs sourceExt to resolve bundler timeout', sha);
      }
      return 'MetroBundlerTimeout patch applied';
    },
  },
  {
    name:  'GradleMemory',
    regex: /java\.lang\.OutOfMemoryError|gradle.*heap|xmx/i,
    async fix(context) {
      logger.info('fix-engine', 'Applying GradleMemory fix — bumping Xmx in gradle.properties');
      try {
        const { content, sha } = await gh.getFileContent('app/android/gradle.properties');
        const patched = content
          .replace(/org\.gradle\.jvmargs=.*/, 'org.gradle.jvmargs=-Xmx4g -XX:MaxMetaspaceSize=512m -XX:+HeapDumpOnOutOfMemoryError');
        await gh.updateFile('app/android/gradle.properties', patched, 'fix(gradle): bump JVM heap to 4 GB', sha);
        return 'GradleMemory patch applied';
      } catch {
        return 'GradleMemory fix skipped — gradle.properties not found';
      }
    },
  },
  {
    name:  'NodeModulesMissing',
    regex: /cannot find module|module not found|missing module/i,
    async fix(context) {
      logger.info('fix-engine', 'Triggering full dependency reinstall workflow');
      await gh.triggerWorkflow('auto-fix-worker.yml', 'main', { action: 'reinstall-deps' });
      return 'NodeModulesMissing fix dispatched';
    },
  },
  {
    name:  'TypeScriptError',
    regex: /TS\d{4}:|error TS/i,
    async fix(context) {
      logger.info('fix-engine', 'TypeScript error detected — logging for manual review');
      await gh.createIssue(
        `[Auto-Fix] TypeScript compile error in run #${context.runId}`,
        `**Run:** #${context.runId}\n**Job:** ${context.jobName}\n\n` +
        `Automatic fix is not safe for TypeScript errors. Manual review required.\n\n` +
        `\`\`\`\n${context.logSnippet || 'No log snippet available'}\n\`\`\``,
        ['auto-fix', 'typescript', 'needs-review']
      );
      return 'TypeScriptError escalated to issue';
    },
  },
  {
    name:  'EASNetworkError',
    regex: /ECONNRESET|ETIMEDOUT|network.*error|fetch.*failed/i,
    async fix(context) {
      logger.info('fix-engine', 'EAS network error — scheduling retry after 5 min');
      await new Promise((r) => setTimeout(r, 5 * 60 * 1000));
      await gh.reRunFailedJobs(context.runId);
      return 'EASNetworkError retry triggered';
    },
  },
];

// ── Engine API ────────────────────────────────────────────────────────────────

async function analyze(logText, context = {}) {
  const matches = FIX_PATTERNS.filter((p) => p.regex.test(logText));
  if (matches.length === 0) {
    logger.info('fix-engine', `No known pattern matched for run #${context.runId}`);
    return { fixed: false, reason: 'No matching fix pattern' };
  }

  const results = [];
  for (const pattern of matches) {
    logger.info('fix-engine', `Matched pattern: ${pattern.name}`);
    try {
      const result = await pattern.fix({ ...context, logSnippet: logText.slice(0, 1000) });
      results.push({ pattern: pattern.name, result, success: true });
    } catch (err) {
      logger.error('fix-engine', `Fix failed for ${pattern.name}: ${err.message}`);
      results.push({ pattern: pattern.name, result: err.message, success: false });
    }
  }

  return { fixed: results.some((r) => r.success), results };
}

module.exports = { analyze, FIX_PATTERNS };
