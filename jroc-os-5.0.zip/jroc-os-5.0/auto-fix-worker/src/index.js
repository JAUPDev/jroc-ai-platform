/**
 * J-Roc OS 5.0 — Auto-Fix Worker: Entry Point
 */
'use strict';

const logger = require('./logger');
const { start } = require('./head-worker');

process.on('uncaughtException',  (err) => logger.error('PROCESS', `Uncaught exception: ${err.message}`, { stack: err.stack }));
process.on('unhandledRejection', (reason) => logger.error('PROCESS', `Unhandled rejection: ${reason}`));

process.on('SIGTERM', () => { logger.info('PROCESS', 'SIGTERM received — shutting down gracefully'); process.exit(0); });
process.on('SIGINT',  () => { logger.info('PROCESS', 'SIGINT received — shutting down gracefully');  process.exit(0); });

logger.info('BOOT', '╔══════════════════════════════════════╗');
logger.info('BOOT', '║   J-Roc OS 5.0 — Auto-Fix Worker    ║');
logger.info('BOOT', '╚══════════════════════════════════════╝');

start();
