/**
 * J-Roc OS 5.0 — Auto-Fix Worker: Centralized Configuration
 */
'use strict';

require('dotenv').config();

module.exports = {
  github: {
    token:  process.env.GITHUB_TOKEN  || '',
    owner:  process.env.GITHUB_OWNER  || '',
    repo:   process.env.GITHUB_REPO   || 'jroc-os',
    apiUrl: 'https://api.github.com',
  },

  expo: {
    token: process.env.EXPO_TOKEN || '',
  },

  worker: {
    pollIntervalMs: parseInt(process.env.WORKER_POLL_INTERVAL_MS || '60000', 10),
    maxRetries:     parseInt(process.env.WORKER_MAX_RETRIES      || '5',     10),
    retryDelayMs:   parseInt(process.env.WORKER_RETRY_DELAY_MS   || '15000', 10),
    concurrency:    parseInt(process.env.WORKER_CONCURRENCY       || '3',     10),
  },

  logging: {
    level:      process.env.LOG_LEVEL       || 'info',
    dir:        process.env.LOG_DIR         || './logs',
    maxSizeMB:  parseInt(process.env.LOG_MAX_SIZE_MB || '10', 10),
    maxFiles:   parseInt(process.env.LOG_MAX_FILES   || '7',  10),
  },

  notify: {
    webhookUrl:    process.env.NOTIFY_WEBHOOK_URL || '',
    onFix:        (process.env.NOTIFY_ON_FIX     || 'true') === 'true',
    onFailure:    (process.env.NOTIFY_ON_FAILURE  || 'true') === 'true',
  },

  nightPatrol: {
    cron: process.env.NIGHT_PATROL_CRON || '0 2 * * *',
    tz:   process.env.NIGHT_PATROL_TZ   || 'America/New_York',
  },
};
