/**
 * J-Roc OS 5.0 — Head Worker (Orchestrator)
 * Polls GitHub Actions for failed runs and dispatches the fix engine.
 */
'use strict';

const schedule   = require('node-schedule');
const pLimit     = require('p-limit');
const gh         = require('./github-client');
const { analyze } = require('./fix-engine');
const notifier   = require('./notifier');
const logger     = require('./logger');
const cfg        = require('./config');

const WATCHED_WORKFLOWS = ['expo-apk.yml', 'auto-fix-worker.yml'];
const limit = pLimit(cfg.worker.concurrency);

// Track runs we've already processed to avoid double-fixing
const processedRuns = new Set();

// ── Core Poll Loop ────────────────────────────────────────────────────────────

async function pollOnce() {
  logger.info('HeadWorker', '── Poll cycle starting ──');

  for (const workflow of WATCHED_WORKFLOWS) {
    try {
      const runs = await gh.getLatestRuns(workflow, 10);
      const failed = runs.filter(
        (r) => r.conclusion === 'failure' && !processedRuns.has(r.id)
      );

      if (failed.length === 0) {
        logger.debug('HeadWorker', `${workflow}: no new failures`);
        continue;
      }

      logger.info('HeadWorker', `${workflow}: ${failed.length} failed run(s) to process`);

      await Promise.all(
        failed.map((run) =>
          limit(() => handleFailedRun(run, workflow))
        )
      );
    } catch (err) {
      logger.error('HeadWorker', `Error polling ${workflow}: ${err.message}`);
    }
  }

  logger.info('HeadWorker', '── Poll cycle complete ──');
}

async function handleFailedRun(run, workflow) {
  const runId = run.id;
  processedRuns.add(runId);

  logger.info('HeadWorker', `Processing failed run #${runId} (${workflow})`);

  // Fetch jobs to get the failing job name
  const jobs    = await gh.getRunJobs(runId).catch(() => []);
  const failJob = jobs.find((j) => j.conclusion === 'failure');
  const jobName = failJob?.name || 'unknown';

  // Fetch and decode logs (ZIP buffer)
  const logBuffer = await gh.getRunLogs(runId);
  const logText   = logBuffer
    ? logBuffer.toString('utf8').slice(0, 50_000)  // first 50 KB
    : '';

  // Run fix engine
  const context = { runId, workflow, jobName };
  const outcome = await analyze(logText, context);

  if (outcome.fixed) {
    logger.info('HeadWorker', `Run #${runId} fixed by ${outcome.results.length} pattern(s)`);
    await notifier.notifyFix({
      runId,
      workflow,
      patterns: outcome.results.map((r) => r.pattern),
      results:  outcome.results,
    });
  } else {
    logger.warn('HeadWorker', `Run #${runId} could not be auto-fixed: ${outcome.reason || 'see results'}`);
    await notifier.notifyFailure({ runId, workflow, reason: outcome.reason || 'No applicable fix' });
  }
}

// ── Night Patrol ──────────────────────────────────────────────────────────────

async function nightPatrol() {
  logger.info('NightPatrol', '🌙 Deep diagnostic scan starting');
  let scanned = 0;
  let issues  = 0;

  for (const workflow of WATCHED_WORKFLOWS) {
    const runs = await gh.getLatestRuns(workflow, 30).catch(() => []);
    for (const run of runs) {
      scanned++;
      if (run.conclusion === 'failure') issues++;
    }
  }

  logger.info('NightPatrol', `Scanned ${scanned} runs, found ${issues} failures`);
  await notifier.notifyNightPatrol({ scanned, issues });
}

// ── Scheduler ─────────────────────────────────────────────────────────────────

function start() {
  logger.info('HeadWorker', `J-Roc OS 5.0 Head Worker starting`);
  logger.info('HeadWorker', `Poll interval: ${cfg.worker.pollIntervalMs}ms | Concurrency: ${cfg.worker.concurrency}`);

  // Immediate first poll
  pollOnce().catch((err) => logger.error('HeadWorker', `Initial poll failed: ${err.message}`));

  // Recurring poll
  setInterval(() => {
    pollOnce().catch((err) => logger.error('HeadWorker', `Poll failed: ${err.message}`));
  }, cfg.worker.pollIntervalMs);

  // Night Patrol cron
  schedule.scheduleJob(
    { rule: cfg.nightPatrol.cron, tz: cfg.nightPatrol.tz },
    () => nightPatrol().catch((err) => logger.error('NightPatrol', err.message))
  );

  logger.info('HeadWorker', `Night Patrol scheduled: ${cfg.nightPatrol.cron} (${cfg.nightPatrol.tz})`);
}

module.exports = { start, pollOnce, nightPatrol };

// Run directly
if (require.main === module) {
  start();
}
