/**
 * J-Roc OS 5.0 — Auto-Fix Worker: Winston Logger
 */
'use strict';

const { createLogger, format, transports } = require('winston');
const path = require('path');
const fs   = require('fs');
const cfg  = require('./config');

// Ensure log directory exists
fs.mkdirSync(cfg.logging.dir, { recursive: true });

const LOG_FILE = path.join(cfg.logging.dir, 'worker.log');
const ERR_FILE = path.join(cfg.logging.dir, 'error.log');

const consoleFormat = format.combine(
  format.colorize(),
  format.timestamp({ format: 'HH:mm:ss' }),
  format.printf(({ timestamp, level, message, worker, ...meta }) => {
    const tag = worker ? `[${worker}]` : '';
    const extra = Object.keys(meta).length ? ` ${JSON.stringify(meta)}` : '';
    return `${timestamp} ${level} ${tag} ${message}${extra}`;
  })
);

const fileFormat = format.combine(
  format.timestamp(),
  format.json()
);

const logger = createLogger({
  level: cfg.logging.level,
  transports: [
    new transports.Console({ format: consoleFormat }),
    new transports.File({
      filename: LOG_FILE,
      format:   fileFormat,
      maxsize:  cfg.logging.maxSizeMB * 1024 * 1024,
      maxFiles: cfg.logging.maxFiles,
      tailable: true,
    }),
    new transports.File({
      filename: ERR_FILE,
      level:    'error',
      format:   fileFormat,
      maxsize:  cfg.logging.maxSizeMB * 1024 * 1024,
      maxFiles: 3,
    }),
  ],
});

module.exports = logger;
