/**
 * J-Roc OS 5.0 — Auto-Fix Worker: GitHub API Client
 */
'use strict';

const axios  = require('axios');
const cfg    = require('./config');
const logger = require('./logger');

const gh = axios.create({
  baseURL: cfg.github.apiUrl,
  headers: {
    Authorization:        `Bearer ${cfg.github.token}`,
    Accept:               'application/vnd.github+json',
    'X-GitHub-Api-Version': '2022-11-28',
    'User-Agent':         'jroc-os-auto-fix-worker/5.0.0',
  },
  timeout: 20_000,
});

// ── Workflow Runs ─────────────────────────────────────────────────────────────

async function getLatestRuns(workflowFile, perPage = 10) {
  const { owner, repo } = cfg.github;
  const res = await gh.get(
    `/repos/${owner}/${repo}/actions/workflows/${workflowFile}/runs`,
    { params: { per_page: perPage } }
  );
  return res.data.workflow_runs;
}

async function getRunJobs(runId) {
  const { owner, repo } = cfg.github;
  const res = await gh.get(`/repos/${owner}/${repo}/actions/runs/${runId}/jobs`);
  return res.data.jobs;
}

async function getRunLogs(runId) {
  const { owner, repo } = cfg.github;
  try {
    const res = await gh.get(
      `/repos/${owner}/${repo}/actions/runs/${runId}/logs`,
      { responseType: 'arraybuffer' }
    );
    return res.data;
  } catch (err) {
    logger.warn('github-client', `Could not fetch logs for run ${runId}: ${err.message}`);
    return null;
  }
}

async function reRunFailedJobs(runId) {
  const { owner, repo } = cfg.github;
  await gh.post(`/repos/${owner}/${repo}/actions/runs/${runId}/rerun-failed-jobs`);
  logger.info('github-client', `Re-run triggered for failed jobs in run #${runId}`);
}

async function triggerWorkflow(workflowFile, ref = 'main', inputs = {}) {
  const { owner, repo } = cfg.github;
  await gh.post(
    `/repos/${owner}/${repo}/actions/workflows/${workflowFile}/dispatches`,
    { ref, inputs }
  );
  logger.info('github-client', `Dispatched workflow ${workflowFile} on ref ${ref}`);
}

// ── File / Commit Operations ──────────────────────────────────────────────────

async function getFileContent(filePath, ref = 'main') {
  const { owner, repo } = cfg.github;
  const res = await gh.get(`/repos/${owner}/${repo}/contents/${filePath}`, {
    params: { ref },
  });
  const content = Buffer.from(res.data.content, 'base64').toString('utf8');
  return { content, sha: res.data.sha };
}

async function updateFile(filePath, newContent, message, sha) {
  const { owner, repo } = cfg.github;
  const encoded = Buffer.from(newContent, 'utf8').toString('base64');
  const res = await gh.put(`/repos/${owner}/${repo}/contents/${filePath}`, {
    message,
    content: encoded,
    sha,
  });
  logger.info('github-client', `Committed fix to ${filePath}: "${message}"`);
  return res.data;
}

// ── Issues ────────────────────────────────────────────────────────────────────

async function createIssue(title, body, labels = ['auto-fix', 'bug']) {
  const { owner, repo } = cfg.github;
  const res = await gh.post(`/repos/${owner}/${repo}/issues`, { title, body, labels });
  logger.info('github-client', `Issue #${res.data.number} created: ${title}`);
  return res.data;
}

module.exports = {
  getLatestRuns,
  getRunJobs,
  getRunLogs,
  reRunFailedJobs,
  triggerWorkflow,
  getFileContent,
  updateFile,
  createIssue,
};
