#!/usr/bin/env bash
# J-Roc OS 5.0 — Auto-Fix Worker: Start Script
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(dirname "$SCRIPT_DIR")"

cd "$ROOT_DIR"

echo "╔══════════════════════════════════════╗"
echo "║   J-Roc OS 5.0 — Auto-Fix Worker    ║"
echo "╚══════════════════════════════════════╝"

# Check Node version
NODE_VER=$(node -v | sed 's/v//')
REQUIRED="20"
if (( ${NODE_VER%%.*} < REQUIRED )); then
  echo "❌ Node.js >= v${REQUIRED} is required (found v${NODE_VER})"
  exit 1
fi

# Ensure .env exists
if [[ ! -f ".env" ]]; then
  echo "⚠️  .env not found — copying from .env.example"
  cp .env.example .env
  echo "✏️  Edit .env and fill in your credentials, then re-run this script."
  exit 1
fi

# Install deps if needed
if [[ ! -d "node_modules" ]]; then
  echo "📦 Installing dependencies…"
  npm install --prefer-offline
fi

# Create logs dir
mkdir -p logs

echo "🚀 Starting Head Worker…"
node src/index.js
