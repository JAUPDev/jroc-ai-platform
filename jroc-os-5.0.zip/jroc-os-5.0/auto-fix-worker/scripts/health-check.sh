#!/usr/bin/env bash
# J-Roc OS 5.0 — Auto-Fix Worker: Health Check
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(dirname "$SCRIPT_DIR")"

cd "$ROOT_DIR"

echo "🔍 J-Roc OS Worker Health Check"
echo "─────────────────────────────────"

PASS=0
FAIL=0

check() {
  local label="$1"
  local cmd="$2"
  if eval "$cmd" &>/dev/null; then
    echo "  ✅ $label"
    ((PASS++))
  else
    echo "  ❌ $label"
    ((FAIL++))
  fi
}

check "Node.js >= 20"        "node -e 'process.exit(parseInt(process.version.slice(1)) >= 20 ? 0 : 1)'"
check ".env file present"    "test -f .env"
check "node_modules present" "test -d node_modules"
check "logs directory"       "test -d logs"
check "GITHUB_TOKEN set"     "grep -q 'GITHUB_TOKEN=gh' .env 2>/dev/null"
check "GITHUB_OWNER set"     "grep -qv 'GITHUB_OWNER=$' .env 2>/dev/null"

echo "─────────────────────────────────"
echo "  Passed: $PASS | Failed: $FAIL"

if [[ $FAIL -gt 0 ]]; then
  exit 1
fi
