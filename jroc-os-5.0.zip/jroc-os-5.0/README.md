# J-Roc OS 5.0

> **A self-healing mobile OS experience** — Expo React Native app paired with an autonomous CI/CD auto-fix worker system.

[![Build Status](https://img.shields.io/github/actions/workflow/status/your-org/jroc-os/expo-apk.yml?label=APK%20Build&style=flat-square)](../../actions/workflows/expo-apk.yml)
[![Auto-Fix Worker](https://img.shields.io/github/actions/workflow/status/your-org/jroc-os/auto-fix-worker.yml?label=Auto-Fix%20Worker&style=flat-square)](../../actions/workflows/auto-fix-worker.yml)
[![Version](https://img.shields.io/badge/version-5.0.0-7c3aed?style=flat-square)](../../releases)
[![License](https://img.shields.io/badge/license-MIT-06d6a0?style=flat-square)](./LICENSE)

---

## 📦 Package Contents

```
jroc-os-5.0/
├── app/                          # Expo React Native mobile app
│   ├── app/                      # expo-router file-based routing
│   │   ├── _layout.tsx           # Root layout (SafeArea, GestureHandler)
│   │   └── (tabs)/               # Tab navigator screens
│   │       ├── _layout.tsx       # Tab bar configuration
│   │       ├── index.tsx         # Home tab
│   │       ├── workers.tsx       # Workers tab
│   │       ├── logs.tsx          # Logs tab
│   │       └── settings.tsx      # Settings tab
│   ├── components/               # Shared UI components
│   │   ├── GlassCard.tsx         # Dark glass-morphism card
│   │   ├── Header.tsx            # App header with actions
│   │   ├── PrimaryButton.tsx     # Multi-variant button
│   │   ├── StatusBadge.tsx       # Online/offline/warning badge
│   │   └── index.ts              # Barrel export
│   ├── screens/                  # Full screen implementations
│   │   ├── HomeScreen.tsx        # Dashboard with system stats
│   │   ├── WorkersScreen.tsx     # Worker toggle & monitoring
│   │   ├── LogsScreen.tsx        # Live log viewer with filters
│   │   ├── SettingsScreen.tsx    # App preferences & maintenance
│   │   └── index.ts              # Barrel export
│   ├── hooks/                    # Custom React hooks
│   │   ├── useApi.ts             # Axios request hook
│   │   ├── useStorage.ts         # MMKV persistent storage
│   │   └── useTheme.ts           # Theme/color scheme hook
│   ├── constants/                # App-wide constants
│   │   ├── Colors.ts             # Design system color palette
│   │   ├── Layout.ts             # Spacing, radius, font sizes
│   │   └── index.ts              # Barrel export
│   ├── utils/                    # Utility functions
│   │   ├── format.ts             # Date, number, string formatters
│   │   ├── logger.ts             # Client-side logger
│   │   └── validation.ts         # Input validators
│   ├── assets/                   # Images, fonts, icons
│   ├── app.json                  # Expo app configuration
│   ├── eas.json                  # EAS Build profiles
│   ├── babel.config.js           # Babel + path aliases
│   ├── tsconfig.json             # TypeScript config
│   └── package.json              # App dependencies
│
├── auto-fix-worker/              # Autonomous self-healing worker system
│   ├── src/
│   │   ├── index.js              # Entry point (process + signal handlers)
│   │   ├── head-worker.js        # Orchestrator — poll loop + scheduler
│   │   ├── fix-engine.js         # Pattern matcher + fix dispatcher
│   │   ├── github-client.js      # GitHub REST API client
│   │   ├── notifier.js           # Slack/webhook notifier
│   │   ├── config.js             # Centralized env config
│   │   ├── logger.js             # Winston logger (file + console)
│   │   └── workers/              # Specialized sub-workers
│   │       ├── build-healer.js   # EAS build failure recovery
│   │       ├── dep-resolver.js   # npm dependency conflict fixer
│   │       ├── lint-guard.js     # ESLint auto-fix dispatcher
│   │       ├── night-patrol.js   # Scheduled deep diagnostic
│   │       └── type-sentinel.js  # TypeScript error tracker
│   ├── scripts/
│   │   ├── run-worker.sh         # Start script with pre-flight checks
│   │   └── health-check.sh       # System readiness checker
│   ├── logs/                     # Runtime log output (git-ignored)
│   ├── .env.example              # Environment variable template
│   └── package.json              # Worker dependencies
│
├── .github/
│   └── workflows/
│       ├── expo-apk.yml          # Expo APK/AAB build pipeline
│       └── auto-fix-worker.yml   # Worker orchestration workflow
│
└── README.md                     # This file
```

---

## 🚀 Quick Start

### Prerequisites

| Tool | Version |
|------|---------|
| Node.js | ≥ 20.x |
| npm | ≥ 10.x |
| Expo CLI | ≥ 51.x |
| EAS CLI | ≥ 7.x |

---

### 1 — Mobile App Setup

```bash
cd app

# Install dependencies
npm install

# Start Expo dev server
npm start

# Run on Android
npm run android

# Run on iOS
npm run ios
```

#### Build a Preview APK

```bash
# Authenticate with EAS
npx eas login

# Build
npx eas build --platform android --profile preview
```

---

### 2 — Auto-Fix Worker Setup

```bash
cd auto-fix-worker

# Copy and configure environment
cp .env.example .env
# Edit .env with your GITHUB_TOKEN, EXPO_TOKEN, etc.

# Run pre-flight health check
bash scripts/health-check.sh

# Start the worker
bash scripts/run-worker.sh
```

The worker will immediately run a poll cycle and then check every 60 seconds (configurable via `WORKER_POLL_INTERVAL_MS`).

---

### 3 — GitHub Actions Setup

Add the following secrets to your repository (`Settings → Secrets → Actions`):

| Secret | Description |
|--------|-------------|
| `EXPO_TOKEN` | Expo access token from expo.dev |
| `PAT_TOKEN` | GitHub Personal Access Token with `repo` + `workflow` scopes (for auto-commits) |
| `SLACK_WEBHOOK_URL` | (Optional) Incoming webhook URL for Slack notifications |

Push to `main` or `develop` to trigger the APK build pipeline automatically.

---

## 🤖 Auto-Fix Worker System

The worker continuously monitors your GitHub Actions runs and applies targeted fixes when failures are detected.

### Fix Patterns

| Pattern | Trigger | Fix Applied |
|---------|---------|------------|
| `MetroBundlerTimeout` | Metro bundler timeout in logs | Patches `metro.config.js` with `cjs` sourceExt |
| `GradleMemory` | `OutOfMemoryError` in Gradle | Bumps `gradle.properties` JVM heap to 4 GB |
| `NodeModulesMissing` | `Cannot find module` errors | Dispatches `reinstall-deps` workflow |
| `TypeScriptError` | `error TS####` patterns | Creates a GitHub issue for manual review |
| `EASNetworkError` | Network timeouts on EAS | Waits 5 minutes then re-runs failed jobs |

### Worker Roster

| Worker | Role | Schedule |
|--------|------|---------|
| **HeadWorker** | Orchestrates all other workers | Every 30 min (CI) / 60s (local) |
| **BuildHealer** | Re-runs failed EAS jobs | On each poll cycle |
| **LintGuard** | ESLint auto-fix dispatcher | On each poll cycle |
| **DepResolver** | npm peer-dep conflict resolution | On each poll cycle |
| **TypeSentinel** | TypeScript error tracker | On each poll cycle |
| **NightPatrol** | Deep diagnostic scan | Daily at 02:00 EDT |

### Manual Triggers

You can trigger any worker action manually via the GitHub Actions UI:

```
Actions → Auto-Fix Worker → Run workflow
```

Actions available: `poll`, `reinstall-deps`, `lint-fix`, `night-patrol`, `health-check`

---

## 🏗️ Architecture

```
┌─────────────────────────────────────────────────────────┐
│                    GitHub Actions                        │
│                                                         │
│  ┌──────────────┐    failure     ┌────────────────────┐ │
│  │  expo-apk    │ ─────────────► │  auto-fix-worker   │ │
│  │  .yml        │                │  .yml              │ │
│  └──────────────┘                └────────────────────┘ │
│         ▲                                │              │
│         │ re-run / commit fix            │ poll / fix   │
│         │                                ▼              │
│  ┌──────────────┐             ┌─────────────────────┐   │
│  │  GitHub Repo │◄────────────│    Head Worker      │   │
│  │  (main)      │  push fix   │    + Fix Engine      │   │
│  └──────────────┘             └─────────────────────┘   │
└─────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────┐
│                    Mobile App (Expo)                     │
│                                                         │
│  HomeScreen ─── WorkersScreen ─── LogsScreen ─── Settings│
│       │               │               │                 │
│  GlassCard      Switch + Badge    Log Viewer            │
│  StatusBadge    Worker Roster     Level Filter          │
│  PrimaryButton  Live Stats        Search                │
└─────────────────────────────────────────────────────────┘
```

---

## 🎨 Design System

| Token | Value |
|-------|-------|
| Background | `#0a0a0f` |
| Surface | `#12121a` |
| Primary | `#7c3aed` (Purple) |
| Accent | `#06d6a0` (Green) |
| Success | `#22c55e` |
| Warning | `#f59e0b` |
| Error | `#ef4444` |

---

## 📋 Environment Variables

See `auto-fix-worker/.env.example` for the full list. Key variables:

```env
GITHUB_TOKEN=ghp_...            # Required: GitHub API access
GITHUB_OWNER=your-username      # Required: repo owner
GITHUB_REPO=jroc-os             # Required: repo name
EXPO_TOKEN=...                  # Required: EAS builds
WORKER_POLL_INTERVAL_MS=60000   # Poll every 60 seconds
NOTIFY_WEBHOOK_URL=...          # Optional: Slack notifications
NIGHT_PATROL_CRON=0 2 * * *    # Default: 02:00 daily
```

---

## 🔒 Security

- Never commit `.env` to version control (it is `.gitignore`d)
- Use GitHub Secrets for all CI credentials
- The auto-fix worker only has write access to files it is explicitly configured to patch
- All worker commits are tagged with `[auto-fix]` for easy audit trail filtering

---

## 📄 License

MIT © J-Roc OS Project — 2026
