import React, { useState, useRef } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  TextInput,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Header } from '@components';
import { Colors, Layout } from '@constants';

type LogLevel = 'DEBUG' | 'INFO' | 'WARN' | 'ERROR';

interface LogEntry {
  id:        number;
  timestamp: string;
  level:     LogLevel;
  source:    string;
  message:   string;
}

const LEVEL_COLOR: Record<LogLevel, string> = {
  DEBUG: Colors.textMuted,
  INFO:  Colors.info,
  WARN:  Colors.warning,
  ERROR: Colors.error,
};

const MOCK_LOGS: LogEntry[] = [
  { id: 1,  timestamp: '09:44:01', level: 'INFO',  source: 'HeadWorker',   message: 'Worker cycle started — 6 agents active' },
  { id: 2,  timestamp: '09:43:58', level: 'INFO',  source: 'BuildHealer',  message: 'expo-apk.yml run #1482 succeeded in 4m 12s' },
  { id: 3,  timestamp: '09:43:55', level: 'DEBUG', source: 'LintGuard',    message: 'ESLint pass: 0 errors, 3 warnings' },
  { id: 4,  timestamp: '09:43:40', level: 'WARN',  source: 'DepResolver',  message: 'react-native-vector-icons: peer dep mismatch (non-fatal)' },
  { id: 5,  timestamp: '09:43:22', level: 'INFO',  source: 'TypeSentinel', message: 'tsc --noEmit: no type errors found' },
  { id: 6,  timestamp: '09:42:10', level: 'ERROR', source: 'BuildHealer',  message: 'Retry #1 — metro bundler timeout; patching metro.config.js' },
  { id: 7,  timestamp: '09:42:08', level: 'INFO',  source: 'BuildHealer',  message: 'Auto-fix applied: added resolver.sourceExts patch' },
  { id: 8,  timestamp: '09:41:55', level: 'DEBUG', source: 'HeadWorker',   message: 'Heartbeat OK — all workers responding' },
  { id: 9,  timestamp: '09:40:00', level: 'INFO',  source: 'LintGuard',    message: 'Auto-fixed 2 import ordering issues' },
  { id: 10, timestamp: '09:38:30', level: 'INFO',  source: 'HeadWorker',   message: 'NightPatrol scheduled for 02:00 EDT' },
];

const FILTERS: (LogLevel | 'ALL')[] = ['ALL', 'DEBUG', 'INFO', 'WARN', 'ERROR'];

export default function LogsScreen() {
  const [activeFilter, setActiveFilter] = useState<LogLevel | 'ALL'>('ALL');
  const [search, setSearch] = useState('');
  const scrollRef = useRef<ScrollView>(null);

  const filtered = MOCK_LOGS.filter((l) => {
    const matchLevel  = activeFilter === 'ALL' || l.level === activeFilter;
    const matchSearch = search === '' || l.message.toLowerCase().includes(search.toLowerCase()) || l.source.toLowerCase().includes(search.toLowerCase());
    return matchLevel && matchSearch;
  });

  return (
    <SafeAreaView style={styles.safe} edges={['bottom']}>
      <Header title="System Logs" subtitle={`${filtered.length} entries`} />

      {/* Search */}
      <View style={styles.searchRow}>
        <TextInput
          style={styles.searchInput}
          value={search}
          onChangeText={setSearch}
          placeholder="Filter logs…"
          placeholderTextColor={Colors.textMuted}
        />
      </View>

      {/* Level Filters */}
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.filterRow}
      >
        {FILTERS.map((f) => (
          <TouchableOpacity
            key={f}
            onPress={() => setActiveFilter(f)}
            style={[styles.filterChip, activeFilter === f && styles.filterChipActive]}
          >
            <Text
              style={[
                styles.filterLabel,
                activeFilter === f
                  ? { color: Colors.textPrimary }
                  : { color: f === 'ALL' ? Colors.textSecondary : LEVEL_COLOR[f as LogLevel] },
              ]}
            >
              {f}
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      {/* Log list */}
      <ScrollView
        ref={scrollRef}
        contentContainerStyle={styles.logScroll}
        style={styles.logContainer}
      >
        {filtered.map((entry) => (
          <View key={entry.id} style={styles.logRow}>
            <Text style={styles.logTimestamp}>{entry.timestamp}</Text>
            <Text style={[styles.logLevel, { color: LEVEL_COLOR[entry.level] }]}>
              {entry.level.padEnd(5)}
            </Text>
            <View style={styles.logBody}>
              <Text style={styles.logSource}>{entry.source}</Text>
              <Text style={styles.logMessage}>{entry.message}</Text>
            </View>
          </View>
        ))}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe:           { flex: 1, backgroundColor: Colors.background },
  searchRow:      { paddingHorizontal: Layout.spacing.md, paddingTop: Layout.spacing.sm },
  searchInput:    { backgroundColor: Colors.surface, borderWidth: 1, borderColor: Colors.border, borderRadius: Layout.radius.md, paddingHorizontal: Layout.spacing.md, height: 40, color: Colors.textPrimary, fontSize: Layout.fontSize.sm },
  filterRow:      { paddingHorizontal: Layout.spacing.md, paddingVertical: Layout.spacing.sm, gap: Layout.spacing.xs },
  filterChip:     { paddingHorizontal: 12, paddingVertical: 6, borderRadius: Layout.radius.full, backgroundColor: Colors.surface, borderWidth: 1, borderColor: Colors.border },
  filterChipActive: { backgroundColor: Colors.primary, borderColor: Colors.primary },
  filterLabel:    { fontSize: Layout.fontSize.xs, fontWeight: '700' },
  logContainer:   { flex: 1 },
  logScroll:      { padding: Layout.spacing.md, gap: 4 },
  logRow:         { flexDirection: 'row', gap: 8, paddingVertical: 4, borderBottomWidth: 1, borderBottomColor: Colors.border },
  logTimestamp:   { color: Colors.textMuted, fontSize: 10, fontFamily: 'monospace', paddingTop: 2 },
  logLevel:       { fontSize: 10, fontFamily: 'monospace', fontWeight: '700', paddingTop: 2, minWidth: 40 },
  logBody:        { flex: 1 },
  logSource:      { color: Colors.primaryLight, fontSize: 10, fontFamily: 'monospace', fontWeight: '700' },
  logMessage:     { color: Colors.textPrimary, fontSize: 11, fontFamily: 'monospace' },
});
