import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  Switch,
  TouchableOpacity,
  Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { GlassCard, Header } from '@components';
import { Colors, Layout, APP_VERSION, BUILD_DATE } from '@constants';
import { formatDate } from '@utils/format';

interface SettingToggle {
  key:     string;
  label:   string;
  sub:     string;
  value:   boolean;
}

export default function SettingsScreen() {
  const [toggles, setToggles] = useState<SettingToggle[]>([
    { key: 'autoFix',    label: 'Auto-Fix Workers',     sub: 'Allow workers to self-patch on failure',    value: true  },
    { key: 'notifications', label: 'Notifications',    sub: 'Push alerts for errors and fixes',          value: true  },
    { key: 'darkMode',   label: 'Dark Mode',            sub: 'Always use dark interface',                 value: true  },
    { key: 'telemetry',  label: 'Usage Telemetry',      sub: 'Anonymous crash & performance reports',     value: false },
    { key: 'nightScan',  label: 'Night Patrol',         sub: 'Run deep diagnostics at 02:00 EDT',        value: true  },
    { key: 'betaFeatures', label: 'Beta Features',      sub: 'Enable experimental capabilities',          value: false },
  ]);

  const flip = (key: string) =>
    setToggles((prev) => prev.map((t) => (t.key === key ? { ...t, value: !t.value } : t)));

  const clearCache = () =>
    Alert.alert('Clear Cache', 'Remove all cached data?', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Clear',  style: 'destructive', onPress: () => {} },
    ]);

  return (
    <SafeAreaView style={styles.safe} edges={['bottom']}>
      <Header title="Settings" />
      <ScrollView contentContainerStyle={styles.scroll}>

        {/* Toggles */}
        <Text style={styles.sectionTitle}>Preferences</Text>
        <GlassCard>
          {toggles.map((t, i) => (
            <View key={t.key} style={[styles.row, i > 0 && styles.rowBorder]}>
              <View style={styles.rowText}>
                <Text style={styles.rowLabel}>{t.label}</Text>
                <Text style={styles.rowSub}>{t.sub}</Text>
              </View>
              <Switch
                value={t.value}
                onValueChange={() => flip(t.key)}
                trackColor={{ false: Colors.border, true: Colors.primary }}
                thumbColor={Colors.textPrimary}
              />
            </View>
          ))}
        </GlassCard>

        {/* Actions */}
        <Text style={styles.sectionTitle}>Maintenance</Text>
        <GlassCard>
          {[
            { label: 'Clear Cache',          action: clearCache,    color: Colors.warning },
            { label: 'Force Worker Restart',  action: () => {},      color: Colors.info    },
            { label: 'Export Logs',           action: () => {},      color: Colors.accent  },
            { label: 'Reset to Defaults',     action: () => {},      color: Colors.error   },
          ].map((a, i) => (
            <TouchableOpacity
              key={a.label}
              style={[styles.row, i > 0 && styles.rowBorder]}
              onPress={a.action}
              activeOpacity={0.7}
            >
              <Text style={[styles.rowLabel, { color: a.color }]}>{a.label}</Text>
              <Text style={styles.chevron}>›</Text>
            </TouchableOpacity>
          ))}
        </GlassCard>

        {/* About */}
        <Text style={styles.sectionTitle}>About</Text>
        <GlassCard>
          {[
            { label: 'Version',    value: APP_VERSION },
            { label: 'Build Date', value: formatDate(BUILD_DATE) },
            { label: 'Platform',   value: 'Android / iOS' },
            { label: 'License',    value: 'MIT' },
          ].map((item, i) => (
            <View key={item.label} style={[styles.row, i > 0 && styles.rowBorder]}>
              <Text style={styles.rowLabel}>{item.label}</Text>
              <Text style={styles.rowSub}>{item.value}</Text>
            </View>
          ))}
        </GlassCard>

      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe:         { flex: 1, backgroundColor: Colors.background },
  scroll:       { padding: Layout.spacing.md, gap: Layout.spacing.xs },
  sectionTitle: { color: Colors.textSecondary, fontSize: Layout.fontSize.xs, fontWeight: '700', textTransform: 'uppercase', letterSpacing: 0.8, marginTop: Layout.spacing.md, marginBottom: Layout.spacing.xs },
  row:          { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingVertical: Layout.spacing.sm },
  rowBorder:    { borderTopWidth: 1, borderTopColor: Colors.border },
  rowText:      { flex: 1, marginRight: Layout.spacing.sm },
  rowLabel:     { color: Colors.textPrimary, fontSize: Layout.fontSize.md },
  rowSub:       { color: Colors.textSecondary, fontSize: Layout.fontSize.xs, marginTop: 2 },
  chevron:      { color: Colors.textMuted, fontSize: 20 },
});
