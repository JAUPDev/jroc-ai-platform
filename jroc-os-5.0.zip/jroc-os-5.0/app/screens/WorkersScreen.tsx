import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  Switch,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { GlassCard, StatusBadge, Header } from '@components';
import { Colors, Layout } from '@constants';

interface Worker {
  id:       string;
  name:     string;
  role:     string;
  status:   'online' | 'offline' | 'warning' | 'error' | 'pending';
  enabled:  boolean;
  lastRun:  string;
  runs:     number;
  fixes:    number;
}

const INITIAL_WORKERS: Worker[] = [
  { id: 'w1', name: 'HeadWorker',      role: 'Orchestrator',       status: 'online',  enabled: true,  lastRun: '2 min ago',  runs: 1482, fixes: 314 },
  { id: 'w2', name: 'BuildHealer',     role: 'CI Fix Engine',      status: 'online',  enabled: true,  lastRun: '8 min ago',  runs: 876,  fixes: 201 },
  { id: 'w3', name: 'LintGuard',       role: 'Code Quality',       status: 'online',  enabled: true,  lastRun: '15 min ago', runs: 2104, fixes: 88  },
  { id: 'w4', name: 'DepResolver',     role: 'Dependency Manager', status: 'warning', enabled: true,  lastRun: '1 hr ago',   runs: 342,  fixes: 57  },
  { id: 'w5', name: 'TypeSentinel',    role: 'Type Checker',       status: 'online',  enabled: true,  lastRun: '5 min ago',  runs: 998,  fixes: 123 },
  { id: 'w6', name: 'NightPatrol',     role: 'Scheduled Auditor',  status: 'pending', enabled: false, lastRun: 'Never',      runs: 0,    fixes: 0   },
];

export default function WorkersScreen() {
  const [workers, setWorkers] = useState<Worker[]>(INITIAL_WORKERS);

  const toggle = (id: string) => {
    setWorkers((prev) =>
      prev.map((w) =>
        w.id === id
          ? { ...w, enabled: !w.enabled, status: !w.enabled ? 'online' : 'offline' }
          : w
      )
    );
  };

  const online  = workers.filter((w) => w.status === 'online').length;
  const warning = workers.filter((w) => w.status === 'warning').length;

  return (
    <SafeAreaView style={styles.safe} edges={['bottom']}>
      <Header title="Workers" subtitle={`${online} active · ${warning} warning`} />
      <ScrollView contentContainerStyle={styles.scroll}>
        {/* Summary */}
        <GlassCard elevated style={styles.summary}>
          <View style={styles.summaryRow}>
            {[
              { label: 'Active',  value: online,                         color: Colors.success },
              { label: 'Warning', value: warning,                        color: Colors.warning },
              { label: 'Total',   value: workers.length,                 color: Colors.primary },
              { label: 'Fixes',   value: workers.reduce((a, w) => a + w.fixes, 0), color: Colors.accent },
            ].map((s) => (
              <View key={s.label} style={styles.summaryItem}>
                <Text style={[styles.summaryVal, { color: s.color }]}>{s.value}</Text>
                <Text style={styles.summaryLbl}>{s.label}</Text>
              </View>
            ))}
          </View>
        </GlassCard>

        {/* Worker Cards */}
        {workers.map((w) => (
          <GlassCard key={w.id} style={styles.workerCard}>
            <View style={styles.workerHeader}>
              <View style={{ flex: 1 }}>
                <Text style={styles.workerName}>{w.name}</Text>
                <Text style={styles.workerRole}>{w.role}</Text>
              </View>
              <Switch
                value={w.enabled}
                onValueChange={() => toggle(w.id)}
                trackColor={{ false: Colors.border, true: Colors.primary }}
                thumbColor={Colors.textPrimary}
              />
            </View>
            <View style={styles.workerFooter}>
              <StatusBadge status={w.status} />
              <Text style={styles.workerMeta}>
                {w.runs} runs · {w.fixes} fixes · {w.lastRun}
              </Text>
            </View>
          </GlassCard>
        ))}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe:        { flex: 1, backgroundColor: Colors.background },
  scroll:      { padding: Layout.spacing.md, gap: Layout.spacing.sm },
  summary:     { marginBottom: Layout.spacing.sm },
  summaryRow:  { flexDirection: 'row', justifyContent: 'space-around' },
  summaryItem: { alignItems: 'center', gap: 4 },
  summaryVal:  { fontSize: Layout.fontSize.xl, fontWeight: '700' },
  summaryLbl:  { fontSize: Layout.fontSize.xs, color: Colors.textSecondary, fontWeight: '600' },
  workerCard:  { gap: Layout.spacing.sm },
  workerHeader:{ flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between' },
  workerName:  { color: Colors.textPrimary, fontSize: Layout.fontSize.md, fontWeight: '700' },
  workerRole:  { color: Colors.textSecondary, fontSize: Layout.fontSize.sm, marginTop: 2 },
  workerFooter:{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  workerMeta:  { color: Colors.textMuted, fontSize: Layout.fontSize.xs },
});
