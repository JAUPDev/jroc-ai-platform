import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  RefreshControl,
  Animated,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { GlassCard, StatusBadge, Header } from '@components';
import { Colors, Layout, APP_VERSION, BUILD_DATE } from '@constants';
import { formatDate } from '@utils/format';

interface SystemStat {
  label: string;
  value: string;
  sub?:  string;
}

const STATS: SystemStat[] = [
  { label: 'CPU',     value: '12%',   sub: '8-core @ 3.2 GHz' },
  { label: 'Memory',  value: '4.2 GB', sub: '8 GB total'        },
  { label: 'Storage', value: '21 GB',  sub: '128 GB available'  },
  { label: 'Battery', value: '87%',    sub: 'Charging'          },
];

export default function HomeScreen() {
  const [refreshing, setRefreshing] = useState(false);
  const fadeAnim = new Animated.Value(0);

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue:         1,
      duration:        600,
      useNativeDriver: true,
    }).start();
  }, []);

  const onRefresh = () => {
    setRefreshing(true);
    setTimeout(() => setRefreshing(false), 1200);
  };

  return (
    <SafeAreaView style={styles.safe} edges={['bottom']}>
      <Header
        title="J-Roc OS"
        subtitle={`v${APP_VERSION} · ${formatDate(BUILD_DATE)}`}
      />
      <ScrollView
        contentContainerStyle={styles.scroll}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            tintColor={Colors.primary}
          />
        }
      >
        <Animated.View style={{ opacity: fadeAnim }}>
          {/* System Status */}
          <GlassCard elevated style={styles.statusCard}>
            <View style={styles.statusRow}>
              <Text style={styles.sectionLabel}>System Status</Text>
              <StatusBadge status="online" />
            </View>
            <Text style={styles.statusSub}>All subsystems nominal</Text>
          </GlassCard>

          {/* Stats Grid */}
          <Text style={styles.sectionTitle}>System Resources</Text>
          <View style={styles.grid}>
            {STATS.map((s) => (
              <GlassCard key={s.label} style={styles.statCard}>
                <Text style={styles.statLabel}>{s.label}</Text>
                <Text style={styles.statValue}>{s.value}</Text>
                {s.sub && <Text style={styles.statSub}>{s.sub}</Text>}
              </GlassCard>
            ))}
          </View>

          {/* Quick Actions */}
          <Text style={styles.sectionTitle}>Quick Actions</Text>
          <GlassCard>
            {['Run Diagnostics', 'Update Workers', 'Clear Cache', 'System Log'].map(
              (action, i) => (
                <View
                  key={action}
                  style={[styles.actionRow, i > 0 && styles.actionBorder]}
                >
                  <Text style={styles.actionLabel}>{action}</Text>
                  <Text style={styles.actionChevron}>›</Text>
                </View>
              )
            )}
          </GlassCard>
        </Animated.View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe:         { flex: 1, backgroundColor: Colors.background },
  scroll:       { padding: Layout.spacing.md, gap: Layout.spacing.sm },
  statusCard:   { marginBottom: Layout.spacing.sm },
  statusRow:    { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  sectionLabel: { color: Colors.textSecondary, fontSize: Layout.fontSize.sm, fontWeight: '600', textTransform: 'uppercase', letterSpacing: 0.8 },
  sectionTitle: { color: Colors.textSecondary, fontSize: Layout.fontSize.sm, fontWeight: '600', textTransform: 'uppercase', letterSpacing: 0.8, marginTop: Layout.spacing.md, marginBottom: Layout.spacing.xs },
  statusSub:    { color: Colors.textPrimary, fontSize: Layout.fontSize.md, fontWeight: '500', marginTop: 6 },
  grid:         { flexDirection: 'row', flexWrap: 'wrap', gap: Layout.spacing.sm },
  statCard:     { flex: 1, minWidth: '45%' },
  statLabel:    { color: Colors.textMuted, fontSize: Layout.fontSize.xs, fontWeight: '600', textTransform: 'uppercase', letterSpacing: 0.6 },
  statValue:    { color: Colors.primaryLight, fontSize: Layout.fontSize.xl, fontWeight: '700', marginTop: 4 },
  statSub:      { color: Colors.textSecondary, fontSize: Layout.fontSize.xs, marginTop: 2 },
  actionRow:    { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingVertical: Layout.spacing.sm },
  actionBorder: { borderTopWidth: 1, borderTopColor: Colors.border },
  actionLabel:  { color: Colors.textPrimary, fontSize: Layout.fontSize.md },
  actionChevron:{ color: Colors.textMuted, fontSize: 20 },
});
