import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Colors, Layout } from '@constants';

type StatusType = 'online' | 'offline' | 'warning' | 'error' | 'pending';

const STATUS_CONFIG: Record<StatusType, { color: string; label: string }> = {
  online:  { color: Colors.success, label: 'Online'  },
  offline: { color: Colors.textMuted, label: 'Offline' },
  warning: { color: Colors.warning, label: 'Warning' },
  error:   { color: Colors.error,   label: 'Error'   },
  pending: { color: Colors.info,    label: 'Pending' },
};

interface StatusBadgeProps {
  status: StatusType;
  showLabel?: boolean;
}

export function StatusBadge({ status, showLabel = true }: StatusBadgeProps) {
  const cfg = STATUS_CONFIG[status];
  return (
    <View style={styles.row}>
      <View style={[styles.dot, { backgroundColor: cfg.color }]} />
      {showLabel && (
        <Text style={[styles.label, { color: cfg.color }]}>{cfg.label}</Text>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  row:   { flexDirection: 'row', alignItems: 'center', gap: 6 },
  dot:   { width: 8, height: 8, borderRadius: 4 },
  label: { fontSize: Layout.fontSize.sm, fontWeight: '600' },
});

export default StatusBadge;
