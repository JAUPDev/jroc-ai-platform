import React from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  StatusBar,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Colors, Layout } from '@constants';

interface HeaderProps {
  title:        string;
  subtitle?:    string;
  leftAction?:  { icon: string; onPress: () => void };
  rightAction?: { icon: string; onPress: () => void };
}

export function Header({ title, subtitle, leftAction, rightAction }: HeaderProps) {
  const insets = useSafeAreaInsets();

  return (
    <View style={[styles.container, { paddingTop: insets.top + 8 }]}>
      <StatusBar barStyle="light-content" backgroundColor={Colors.background} />

      {leftAction ? (
        <TouchableOpacity style={styles.action} onPress={leftAction.onPress}>
          <Text style={styles.actionIcon}>{leftAction.icon}</Text>
        </TouchableOpacity>
      ) : (
        <View style={styles.actionPlaceholder} />
      )}

      <View style={styles.center}>
        <Text style={styles.title} numberOfLines={1}>{title}</Text>
        {subtitle ? (
          <Text style={styles.subtitle} numberOfLines={1}>{subtitle}</Text>
        ) : null}
      </View>

      {rightAction ? (
        <TouchableOpacity style={styles.action} onPress={rightAction.onPress}>
          <Text style={styles.actionIcon}>{rightAction.icon}</Text>
        </TouchableOpacity>
      ) : (
        <View style={styles.actionPlaceholder} />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection:   'row',
    alignItems:      'center',
    paddingBottom:   12,
    paddingHorizontal: Layout.spacing.md,
    backgroundColor: Colors.background,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  center: {
    flex:      1,
    alignItems: 'center',
  },
  title: {
    color:      Colors.textPrimary,
    fontSize:   Layout.fontSize.lg,
    fontWeight: '700',
  },
  subtitle: {
    color:    Colors.textSecondary,
    fontSize: Layout.fontSize.xs,
    marginTop: 2,
  },
  action: {
    width:          40,
    height:         40,
    alignItems:     'center',
    justifyContent: 'center',
    borderRadius:   Layout.radius.full,
    backgroundColor: Colors.surfaceAlt,
  },
  actionIcon:      { fontSize: 18, color: Colors.textPrimary },
  actionPlaceholder: { width: 40 },
});

export default Header;
