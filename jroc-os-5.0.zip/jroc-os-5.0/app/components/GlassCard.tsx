import React from 'react';
import {
  View,
  StyleSheet,
  ViewStyle,
  StyleProp,
} from 'react-native';
import { Colors, Layout } from '@constants';

interface GlassCardProps {
  children:  React.ReactNode;
  style?:    StyleProp<ViewStyle>;
  padded?:   boolean;
  elevated?: boolean;
}

export function GlassCard({
  children,
  style,
  padded   = true,
  elevated = false,
}: GlassCardProps) {
  return (
    <View
      style={[
        styles.card,
        padded   && styles.padded,
        elevated && styles.elevated,
        style,
      ]}
    >
      {children}
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: Colors.surface,
    borderRadius:    Layout.radius.lg,
    borderWidth:     1,
    borderColor:     Colors.border,
    overflow:        'hidden',
  },
  padded: {
    padding: Layout.spacing.md,
  },
  elevated: {
    shadowColor:   Colors.primary,
    shadowOffset:  { width: 0, height: 4 },
    shadowOpacity: 0.25,
    shadowRadius:  12,
    elevation:     8,
  },
});

export default GlassCard;
