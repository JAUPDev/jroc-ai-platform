import React from 'react';
import {
  TouchableOpacity,
  Text,
  StyleSheet,
  ActivityIndicator,
  ViewStyle,
  StyleProp,
} from 'react-native';
import { Colors, Layout } from '@constants';

interface PrimaryButtonProps {
  label:     string;
  onPress:   () => void;
  loading?:  boolean;
  disabled?: boolean;
  variant?:  'primary' | 'accent' | 'ghost' | 'danger';
  style?:    StyleProp<ViewStyle>;
  fullWidth?: boolean;
}

export function PrimaryButton({
  label,
  onPress,
  loading   = false,
  disabled  = false,
  variant   = 'primary',
  style,
  fullWidth = false,
}: PrimaryButtonProps) {
  const isDisabled = disabled || loading;

  return (
    <TouchableOpacity
      activeOpacity={0.75}
      onPress={onPress}
      disabled={isDisabled}
      style={[
        styles.base,
        styles[variant],
        fullWidth && styles.fullWidth,
        isDisabled && styles.disabled,
        style,
      ]}
    >
      {loading ? (
        <ActivityIndicator color={Colors.textPrimary} size="small" />
      ) : (
        <Text style={[styles.label, variant === 'ghost' && styles.ghostLabel]}>
          {label}
        </Text>
      )}
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  base: {
    height:         48,
    borderRadius:   Layout.radius.md,
    alignItems:     'center',
    justifyContent: 'center',
    paddingHorizontal: Layout.spacing.lg,
  },
  primary: { backgroundColor: Colors.primary },
  accent:  { backgroundColor: Colors.accent },
  ghost: {
    backgroundColor: 'transparent',
    borderWidth:     1,
    borderColor:     Colors.border,
  },
  danger: { backgroundColor: Colors.error },
  fullWidth: { width: '100%' },
  disabled: { opacity: 0.45 },
  label: {
    color:      Colors.textPrimary,
    fontSize:   Layout.fontSize.md,
    fontWeight: '600',
  },
  ghostLabel: { color: Colors.textSecondary },
});

export default PrimaryButton;
