import WorkersScreen from '@screens/WorkersScreen';
export default WorkersScreen;
