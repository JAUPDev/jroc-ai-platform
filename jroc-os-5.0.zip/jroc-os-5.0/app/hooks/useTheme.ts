import { useColorScheme } from 'react-native';
import { Colors } from '@constants';

export function useTheme() {
  const scheme = useColorScheme();
  // J-Roc OS is always dark-first; light mode gets a softer dark variant
  const isDark = scheme !== 'light';

  return {
    isDark,
    colors: Colors,
    scheme,
  };
}
