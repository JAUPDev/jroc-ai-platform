import { useState, useCallback } from 'react';
import axios, { AxiosRequestConfig } from 'axios';
import { API } from '@constants';

interface ApiState<T> {
  data:    T | null;
  loading: boolean;
  error:   string | null;
}

export function useApi<T = unknown>() {
  const [state, setState] = useState<ApiState<T>>({
    data:    null,
    loading: false,
    error:   null,
  });

  const request = useCallback(
    async (endpoint: string, config?: AxiosRequestConfig): Promise<T | null> => {
      setState({ data: null, loading: true, error: null });
      try {
        const response = await axios.request<T>({
          baseURL: API.BASE_URL,
          url:     endpoint,
          timeout: API.TIMEOUT_MS,
          ...config,
        });
        setState({ data: response.data, loading: false, error: null });
        return response.data;
      } catch (err: unknown) {
        const msg =
          axios.isAxiosError(err)
            ? (err.response?.data?.message ?? err.message)
            : 'Unknown error occurred';
        setState({ data: null, loading: false, error: msg });
        return null;
      }
    },
    []
  );

  const get  = (url: string, cfg?: AxiosRequestConfig) => request(url, { method: 'GET',    ...cfg });
  const post = (url: string, data: unknown, cfg?: AxiosRequestConfig) =>
    request(url, { method: 'POST', data, ...cfg });
  const put  = (url: string, data: unknown, cfg?: AxiosRequestConfig) =>
    request(url, { method: 'PUT',  data, ...cfg });
  const del  = (url: string, cfg?: AxiosRequestConfig) => request(url, { method: 'DELETE', ...cfg });

  return { ...state, get, post, put, del };
}
