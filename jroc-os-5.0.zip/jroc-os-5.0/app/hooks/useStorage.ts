import { MMKV } from 'react-native-mmkv';
import { STORAGE_KEYS } from '@constants';

const storage = new MMKV({ id: 'jroc-os-store' });

export function useStorage() {
  function get<T>(key: string, fallback: T): T {
    const raw = storage.getString(key);
    if (raw === undefined) return fallback;
    try {
      return JSON.parse(raw) as T;
    } catch {
      return fallback;
    }
  }

  function set<T>(key: string, value: T): void {
    storage.set(key, JSON.stringify(value));
  }

  function remove(key: string): void {
    storage.delete(key);
  }

  function clear(): void {
    storage.clearAll();
  }

  return { get, set, remove, clear, KEYS: STORAGE_KEYS };
}
