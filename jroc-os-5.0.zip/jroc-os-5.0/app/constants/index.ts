export { Colors }  from './Colors';
export { Layout }  from './Layout';

export const APP_NAME    = 'J-Roc OS';
export const APP_VERSION = '5.0.0';
export const BUILD_DATE  = '2026-09-01';

export const API = {
  BASE_URL:    'https://api.jrocos.io/v5',
  TIMEOUT_MS:  12000,
  RETRY_LIMIT: 3,
};

export const STORAGE_KEYS = {
  USER_PREFS:   'jros:user_prefs',
  AUTH_TOKEN:   'jros:auth_token',
  THEME:        'jros:theme',
  ONBOARDING:   'jros:onboarding_done',
  CACHE_PREFIX: 'jros:cache:',
};

export const ANIMATION = {
  FAST:   150,
  NORMAL: 300,
  SLOW:   500,
};
