import { Dimensions } from 'react-native';

const { width, height } = Dimensions.get('window');

export const Layout = {
  window: { width, height },
  isSmallDevice: width < 375,
  isLargeDevice: width >= 414,

  spacing: {
    xs:  4,
    sm:  8,
    md:  16,
    lg:  24,
    xl:  32,
    xxl: 48,
  },

  radius: {
    sm:   6,
    md:   12,
    lg:   18,
    xl:   24,
    full: 9999,
  },

  fontSize: {
    xs:   11,
    sm:   13,
    md:   15,
    lg:   18,
    xl:   22,
    xxl:  28,
    hero: 36,
  },

  iconSize: {
    sm: 16,
    md: 22,
    lg: 28,
    xl: 36,
  },

  tabBarHeight:    64,
  headerHeight:    56,
  statusBarHeight: 44,
};

export default Layout;
