export const Colors = {
  // Core palette
  background:     '#0a0a0f',
  surface:        '#12121a',
  surfaceAlt:     '#1a1a26',
  border:         '#2a2a3d',

  // Brand
  primary:        '#7c3aed',
  primaryLight:   '#a855f7',
  primaryDark:    '#5b21b6',
  accent:         '#06d6a0',
  accentAlt:      '#00b4d8',

  // Status
  success:        '#22c55e',
  warning:        '#f59e0b',
  error:          '#ef4444',
  info:           '#3b82f6',

  // Text
  textPrimary:    '#f1f5f9',
  textSecondary:  '#94a3b8',
  textMuted:      '#475569',
  textInverse:    '#0a0a0f',

  // Gradients (start/end pairs)
  gradientPurple: ['#7c3aed', '#4f46e5'],
  gradientGreen:  ['#06d6a0', '#0ea5e9'],
  gradientFire:   ['#f59e0b', '#ef4444'],

  // Transparent overlays
  overlay:        'rgba(10,10,15,0.85)',
  overlayLight:   'rgba(124,58,237,0.12)',
};

export default Colors;
