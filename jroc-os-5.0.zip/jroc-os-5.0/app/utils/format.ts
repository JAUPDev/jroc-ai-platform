import { format, formatDistanceToNow, parseISO } from 'date-fns';

/** Format an ISO date string to a human-readable date */
export function formatDate(iso: string, pattern = 'MMM d, yyyy'): string {
  try { return format(parseISO(iso), pattern); }
  catch { return iso; }
}

/** "3 hours ago" style relative time */
export function timeAgo(iso: string): string {
  try { return formatDistanceToNow(parseISO(iso), { addSuffix: true }); }
  catch { return iso; }
}

/** Format a number as a compact string: 1200 → "1.2K" */
export function compactNumber(n: number): string {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`;
  if (n >= 1_000)     return `${(n / 1_000).toFixed(1)}K`;
  return String(n);
}

/** Clamp a string to a max character length with ellipsis */
export function truncate(str: string, max = 80): string {
  return str.length > max ? `${str.slice(0, max - 1)}…` : str;
}

/** Capitalize first letter */
export function capitalize(str: string): string {
  return str.charAt(0).toUpperCase() + str.slice(1);
}
