type LogLevel = 'debug' | 'info' | 'warn' | 'error';

const LOG_LEVELS: Record<LogLevel, number> = {
  debug: 0,
  info:  1,
  warn:  2,
  error: 3,
};

const MIN_LEVEL: LogLevel = __DEV__ ? 'debug' : 'warn';

function log(level: LogLevel, tag: string, ...args: unknown[]) {
  if (LOG_LEVELS[level] < LOG_LEVELS[MIN_LEVEL]) return;
  const ts = new Date().toISOString();
  const prefix = `[${ts}] [${level.toUpperCase()}] [${tag}]`;
  switch (level) {
    case 'debug': console.debug(prefix, ...args); break;
    case 'info':  console.info(prefix,  ...args); break;
    case 'warn':  console.warn(prefix,  ...args); break;
    case 'error': console.error(prefix, ...args); break;
  }
}

export const logger = {
  debug: (tag: string, ...args: unknown[]) => log('debug', tag, ...args),
  info:  (tag: string, ...args: unknown[]) => log('info',  tag, ...args),
  warn:  (tag: string, ...args: unknown[]) => log('warn',  tag, ...args),
  error: (tag: string, ...args: unknown[]) => log('error', tag, ...args),
};
