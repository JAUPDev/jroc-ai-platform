/** Simple runtime validators */

export function isEmail(value: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value.trim());
}

export function isURL(value: string): boolean {
  try { new URL(value); return true; } catch { return false; }
}

export function isNonEmpty(value: string): boolean {
  return value.trim().length > 0;
}

export function isWithinRange(n: number, min: number, max: number): boolean {
  return n >= min && n <= max;
}

export function isValidVersion(v: string): boolean {
  return /^\d+\.\d+\.\d+$/.test(v);
}

export function sanitize(input: string): string {
  return input.replace(/[<>"'`]/g, '').trim();
}
